import * as Yup from "yup";

export const datosCotizacionSchema = Yup.object().shape({
	fecha: Yup.date().required("Es requerido"),
});

export const datosPresupuestoSchema = Yup.object().shape({
	nombres: Yup.string().required("Es requerido"),
	telefono: Yup.string()
		.min(9, "El mínimo de caracteres es 9")
		.required("Es requerido"),
	email: Yup.string().email("Email inválido").required("Es requerido"),
	ruc: Yup.string()
		.min(11, "El mínimo de caracteres es 11")
		.required("Es requerido"),
	cantidadEmpleados: Yup.string().required("Es requerido"),
	empresa: Yup.string().required("Es requerido"),
});
