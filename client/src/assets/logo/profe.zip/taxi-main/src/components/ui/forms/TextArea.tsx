import React from "react";
import styles from "./textarea.module.css";
import { Field } from "formik";
type TextareaProps = {
	label: string;
	handleBlur: any;
	name: string;
	isError: any;
	touched: any;
	limitChar: number;
	stateField: string;
};
function TextArea({
	label,
	handleBlur,
	name,
	isError,
	touched,
	limitChar,
	stateField,
}: TextareaProps) {
	return (
		<div>
			<div className={styles.containerTextarea}>
				<Field
					as="textarea"
					cols={30}
					rows={4}
					name={name}
					onBlur={handleBlur}
					id={label}
					placeholder=" "
					className={
						" text-gray-600 border-b-2 rounded-lg border-gray-200 focus:border-primary outline-none focus:outline-none focus:ring-0 " +
						styles.textareaCustom +
						" " +
						(isError && touched ? styles.textareaCustomError : "")
					}
				/>
				<label htmlFor={label} className={styles.labelTextarea}>
					{label}
				</label>
			</div>
			<div className="flex justify-between w-full  font-medium">
				{isError && touched && (
					<div className="text-red-500 text-xs p-1">{isError}</div>
				)}
				<span
					className={`text-xs ${
						stateField.length > limitChar && "text-red-500"
					}`}
				>
					{stateField.length}/{limitChar}
				</span>
			</div>
		</div>
	);
}

export default TextArea;
