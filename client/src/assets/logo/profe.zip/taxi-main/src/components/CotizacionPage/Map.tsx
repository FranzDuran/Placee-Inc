import { useMemo, useState, useImperativeHandle, forwardRef } from "react";
import {
	GoogleMap,
	useLoadScript,
	Marker,
	DirectionsRenderer,
} from "@react-google-maps/api";
//center: [-77.06937521389499, -12.052965528639364],
const Map = forwardRef(function Map(
	{
		directionsResponse,
	}: {
		directionsResponse: any;
	},
	ref
) {
	const center = useMemo(
		() => ({ lat: -12.052965528639364, lng: -77.06937521389499 }),
		[]
	);
	const [selectedLocation, setLocation] = useState(null) as any;
	const [originSelector, setLocationOrigin] = useState(null) as any;

	useImperativeHandle(ref, () => ({
		setSelectedLocation: (lat: any, lng: any) => setLocation({ lat, lng }),
		setSelectedLocationOrigin: (lat: any, lng: any) =>
			setLocationOrigin({ lat, lng }),
	}));

	return (
		<GoogleMap
			mapContainerStyle={{
				width: "100%",
				height: "100%",
				color: "white",
			}}
			zoom={13}
			options={{
				noClear: false,
			}}
			center={center}
			mapContainerClassName="map-container"
		>
			{!directionsResponse && originSelector && (
				<Marker label="A" position={originSelector} />
			)}
			{!directionsResponse && selectedLocation && (
				<Marker label="B" position={selectedLocation} />
			)}
			{directionsResponse && (
				<DirectionsRenderer directions={directionsResponse} />
			)}
		</GoogleMap>
	);
});

export default Map;
