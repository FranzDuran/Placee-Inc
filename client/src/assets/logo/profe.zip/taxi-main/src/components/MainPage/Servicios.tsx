import React from "react";
import { motion } from "framer-motion";
import { BsTaxiFrontFill } from "react-icons/bs";
import {
	MdEvent,
	MdLocalAirport,
	MdOutlineCorporateFare,
} from "react-icons/md";

import { RiVipCrownFill } from "react-icons/ri";
import { BiTrip } from "react-icons/bi";
import { useTranslation } from "next-i18next";
import { useRouter } from "next/router";

const servicios = [
	{
		title: "Traslados al aeropuerto",
		description:
			": Ofrecemos servicios de traslado al aeropuerto para nuestros clientes VIP, asegurándonos de que lleguen a tiempo y de manera segura a su destino.",
		icon: <MdLocalAirport className="text-primary/80 text-4xl" />,
	},
	{
		title: "Traslados para eventos",
		description:
			"Ofrecemos servicios de traslado para eventos especiales, como bodas, reuniones de negocios, conciertos, entre otros.",
		icon: <MdEvent className="text-primary/80 text-4xl" />,
	},
	{
		title: "Servicios de chofer personal",
		description:
			"Ofrecemos servicios de chofer personal para nuestros clientes VIP, proporcionando un conductor profesional y altamente capacitado para atender sus necesidades de transporte.",
		icon: <RiVipCrownFill className="text-primary/80 text-4xl" />,
	},
	{
		title: "Tours de ciudad",
		description:
			"Ofrecemos tours de ciudad personalizados para nuestros clientes VIP, brindando una experiencia única para conocer los lugares más emblemáticos de nuestra ciudad.",
		icon: <BsTaxiFrontFill className="text-primary/80 text-4xl" />,
	},
	{
		title: "Transporte corporativo",
		description:
			"Ofrecemos servicios de transporte corporativo para empresas, brindando soluciones personalizadas para sus necesidades de transporte.",
		icon: <MdOutlineCorporateFare className="text-primary/80 text-4xl" />,
	},
	{
		title: "Viajes de larga distancia",
		description:
			"Ofrecemos servicios de transporte VIP para viajes de larga distancia, asegurándonos de que nuestros clientes lleguen a su destino final de manera segura y cómoda.",
		icon: <BiTrip className="text-primary/80 text-4xl" />,
	},
];

const serviciosEnglish = [
	{
		title: "Airport transfers",
		description:
			"We offer airport transfer services for our VIP clients, making sure they arrive on time and safely at their destination.",
		icon: <MdLocalAirport className="text-primary/80 text-4xl" />,
	},
	{
		title: "Transfers for events",
		description:
			"We offer transfer services for special events, such as weddings, business meetings, concerts, among others.",
		icon: <MdEvent className="text-primary/80 text-4xl" />,
	},
	{
		title: "Personal chauffeur services",
		description:
			"We offer personal chauffeur services for our VIP clients, providing a professional and highly trained driver to attend to your transportation needs.",
		icon: <RiVipCrownFill className="text-primary/80 text-4xl" />,
	},
	{
		title: "City tours",
		description:
			"We offer personalized city tours for our VIP clients, providing a unique experience to get to know the most emblematic places in our city.",
		icon: <BsTaxiFrontFill className="text-primary/80 text-4xl" />,
	},
	{
		title: "Corporate transport",
		description:
			"Ofrecemos servicios de transporte corporativo para empresas, brindando soluciones personalizadas para sus necesidades de transporte.",
		icon: <MdOutlineCorporateFare className="text-primary/80 text-4xl" />,
	},
	{
		title: "Long-distance trips",
		description:
			"We offer VIP transportation services for long-distance journeys, making sure that our clients reach their final destination safely and comfortably.",
		icon: <BiTrip className="text-primary/80 text-4xl" />,
	},
];

function Servicios() {
	const { t } = useTranslation("services");

	const router = useRouter();

	return (
		<>
			<div className="lg:text-center my-12 p-2 overflow-hidden relative mb-4">
				<div id="nosotros" className="absolute top-[-95px]" />
				<motion.h4
					initial={{ opacity: 0, x: -100 }}
					whileInView={{ opacity: 1, x: 0 }}
					viewport={{ once: true }}
					transition={{ duration: 0.5 }}
					className="text-stone-700 mb-3 text-4xl lg:text-4xl font-bold"
				>
					{t("title")}
				</motion.h4>
				<motion.p
					initial={{ opacity: 0, x: -100 }}
					whileInView={{ opacity: 1, x: 0 }}
					viewport={{ once: true }}
					transition={{ duration: 0.5 }}
					className="text-gray-500 text-sm lg:text-base"
				>
					{t("subtitle")}
				</motion.p>

				<div className="flex flex-wrap max-w-6xl mx-auto justify-center items-center gap-8">
					{router.locale === "es"
						? servicios.map((item, index) => (
								<motion.div
									initial={{ opacity: 0, y: 100 }}
									whileInView={{ opacity: 1, y: 0 }}
									viewport={{ once: true }}
									transition={{ duration: 0.5, delay: index * 0.1 }}
									className="flex flex-col gap-2 items-center border rounded-full max-w-xs p-4 shadow-md hover:shadow-lg transition duration-300 ease-in-out"
									key={item.title}
								>
									{item.icon}
									<div className="p-3">
										<p>{item.title}</p>
										<p className="text-xs text-gray-500">{item.description}</p>
									</div>
								</motion.div>
						  ))
						: serviciosEnglish.map((item, index) => (
								<motion.div
									initial={{ opacity: 0, y: 100 }}
									whileInView={{ opacity: 1, y: 0 }}
									viewport={{ once: true }}
									transition={{ duration: 0.5, delay: index * 0.1 }}
									className="flex flex-col gap-2 items-center border rounded-full max-w-xs p-4 shadow-md hover:shadow-lg transition duration-300 ease-in-out"
									key={item.title}
								>
									{item.icon}
									<div className="p-3">
										<p>{item.title}</p>
										<p className="text-xs text-gray-500">{item.description}</p>
									</div>
								</motion.div>
						  ))}
				</div>
				<p className="text-center text-gray-600 text-sm mt-4">
					{t("extra-text")}
				</p>
			</div>
		</>
	);
}

export default Servicios;
