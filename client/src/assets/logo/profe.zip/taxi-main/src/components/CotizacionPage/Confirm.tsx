import React from "react";

function Confirm() {
	return <div>Confirm</div>;
}

export default Confirm;
