import React from "react";

function Contacto() {
	return <div>Contacto</div>;
}

export default Contacto;
