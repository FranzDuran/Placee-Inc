import React from "react";

import busImage from "../../../public/cars/bus.png";
import confortImage from "../../../public/cars/confort.png";
import standarImage from "../../../public/cars/standar.png";
import exclusivoImage from "../../../public/cars/exclusivo.png";
import premiumImage from "../../../public/cars/premium.png";
import urbanImage from "../../../public/cars/urban.png";
import vanImage from "../../../public/cars/van.png";
import Image from "next/image";
import { FaSuitcaseRolling, FaUsers } from "react-icons/fa";
import Link from "next/link";
import { useTranslation } from "next-i18next";

const vehicles = [
	{
		name: "Standar",
		description: "Sedan Básico",
		minPrice: 15,
		image: standarImage,
		price: 2.2,
		contactar: false,
		capacity: 3,
		maletas: 2,
	},
	{
		name: "Ejecutivo VIP",
		description: "Sedan Moderno",
		minPrice: 20,
		image: exclusivoImage,
		price: 2.5,
		contactar: false,
		capacity: 4,
		maletas: 3,
	},
	{
		name: "Confort",
		description: "Suv",
		minPrice: 25,
		image: confortImage,
		price: 3.5,
		contactar: false,
		capacity: 4,
		maletas: 4,
	},
	{
		name: "Premium",
		description: "Suv",
		minPrice: 30,
		image: premiumImage,
		price: 4.5,
		contactar: false,
		capacity: 6,
		maletas: 4,
	},
	{
		name: "Van",
		description: "Van",
		minPrice: 70,
		image: vanImage,
		contactar: false,
		price: 6,
		capacity: 8,
		maletas: 7,
	},
	{
		name: "Urban",
		contactar: true,
		image: urbanImage,
	},
	{
		name: "Bus",
		contactar: true,
		image: busImage,
	},
];

const calculatePrice = (
	minPrice: number,
	distance: number,
	price: number,
	originValue: string,
	destinationValue: string
) => {
	const isAeroport =
		/aeropuerto/i.test(originValue) || /aeropuerto/i.test(destinationValue);

	const priceBase = (distance * price).toFixed(2);
	if (minPrice > +priceBase) {
		return minPrice + (isAeroport ? 15 : 0);
	}
	if (isAeroport) {
		return +priceBase + 15;
	}
	return +priceBase;
};

type Vehicle = {
	name: string;
	description: string;
	minPrice: number;
	image: string;
	price: number;
	contactar: false;
	capacity: number;
	maletas: number;
};
function Vehiculos({
	distance,
	typeVehicle,
	setTypeVehicle,
	origin,
	destination,
}: {
	distance: number;
	typeVehicle: Vehicle | null;
	setTypeVehicle: any;
	origin: string;
	destination: string;
}) {
	const { t } = useTranslation("main");
	return (
		<div className="flex flex-col w-full gap-3 items-center">
			{vehicles.map((item) => {
				if (!item.price) {
					return (
						<div
							key={item.name}
							className="w-full text-gray-500   items-center flex justify-between py-2 px-4 border"
						>
							<div className="flex flex-col items-center text-xs ">
								<Image
									alt={item.name}
									src={item.image}
									height={150}
									width={150}
								/>
							</div>
							<div className="flex flex-col gap-3 items-center">
								<div className="flex flex-col items-center">
									<h6 className="font-bold text-sm md:text-base">
										{item.name}
									</h6>
								</div>
								<Link
									href={`https://wa.me/51960607020?text=Hola%20quiero%20mas%20informacion%20sobre%20un%20viaje%20con%20el%20vehiculo%20${item.name}`}
									target="_blank"
									className="btn text-sm px-4 py-2"
								>
									{t("contact")}
								</Link>
							</div>
						</div>
					);
				}

				if (item.contactar === false) {
					const price = calculatePrice(
						item.minPrice!,
						distance,
						item.price!,
						origin,
						destination
					);
					return (
						<div
							key={item.name}
							onClick={() => {
								setTypeVehicle(item);
							}}
							className={`w-full cursor-pointer rounded-md text-gray-500 items-center flex justify-between py-2  border ${
								item.name === typeVehicle?.name &&
								"bg-gradient-to-r from-primary via-blue-500 to-primary text-white"
							}`}
						>
							<div className="flex flex-col items-center text-xs">
								<div className="relative w-28 h-20 md:w-36 md:h-24">
									<Image alt={item.name} src={item.image} fill />
								</div>

								<p className="text-xs">{item.description}</p>
							</div>
							<div className="flex flex-col text-center items-center">
								<h6 className="font-bold text-xs sm:text-sm md:text-base">
									{item.name}
								</h6>
							</div>
							<div className="flex flex-col md:flex-row md:gap-12 px-3 gap-1 items-center">
								<div className="flex flex-col items-center gap-2">
									<span>S/ {price}</span>

									<div className="flex gap-3 items-center">
										<p className="text-xs flex items-center gap-1">
											<FaUsers size={15} />
											{item.capacity}{" "}
											<span className="hidden sm:block">Max</span>
										</p>
										<p className="text-xs flex items-center gap-1">
											<FaSuitcaseRolling size={15} />
											{item.maletas}
											<span className="hidden sm:block">Max</span>
										</p>
									</div>
								</div>
							</div>
						</div>
					);
				}
			})}
		</div>
	);
}

export default Vehiculos;
