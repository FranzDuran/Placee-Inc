import React from "react";
import { HiUser } from "react-icons/hi2";

function Input({ refInputName }: { refInputName: string }) {
	return (
		<div className="relative">
			<HiUser size={20} className="absolute top-6 left-3 text-primary" />
			<input
				ref={refInputName}
				// disabled={!ready}

				className="my-2 rounded-md outline-primary focus:border-primary focus:ring-primary shadow-md border py-3 px-9 w-full"
				placeholder="Tu nombre"
			/>
		</div>
	);
}

export default Input;
