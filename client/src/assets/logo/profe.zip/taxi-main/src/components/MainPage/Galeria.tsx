import { useEffect, useState, useRef } from "react";
import image1 from "../../../public/nosotros1.png";
import image2 from "../../../public/nosotros2.png";
import image3 from "../../../public/nosotros3.png";

import { BsChevronLeft, BsChevronRight } from "react-icons/bs";
import Image from "next/image";

import { Navigation, Pagination, Scrollbar, A11y, Autoplay } from "swiper";

import { Swiper, SwiperSlide } from "swiper/react";

import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/scrollbar";

function Galeria() {
	return (
		<div className="scrollbar-hide max-w-5xl w-screen my-4 mx-auto">
			<Swiper
				modules={[Scrollbar, A11y, Autoplay]}
				spaceBetween={0}
				grabCursor={true}
				slidesPerView={2}
				autoplay={{ delay: 2000 }}
			>
				<SwiperSlide className="mx-3">
					<Image
						height={400}
						width={400}
						src={image1}
						loading="lazy"
						alt="sadas"
						className="rounded-md mx-auto  skew-y-3"
					/>
				</SwiperSlide>
				<SwiperSlide className="mx-3">
					<Image
						height={400}
						width={400}
						src={image2}
						loading="lazy"
						alt="sadas"
						className="rounded-md mx-auto   skew-y-3"
					/>
				</SwiperSlide>
				<SwiperSlide className="mx-3 my-auto flex items-center">
					<Image
						height={500}
						width={500}
						loading="lazy"
						src={image3}
						alt="sadas"
						className="rounded-md mx-auto   skew-y-3"
					/>
				</SwiperSlide>
			</Swiper>
		</div>
	);
}

export default Galeria;
