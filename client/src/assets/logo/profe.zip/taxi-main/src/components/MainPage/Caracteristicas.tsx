import React from "react";
import { MdSecurity } from "react-icons/md";
import { IoCheckmarkDone } from "react-icons/io5";
import { BiTimer } from "react-icons/bi";
import { motion } from "framer-motion";
import { useTranslation } from "next-i18next";

function Caracteristicas() {
	const { t } = useTranslation("main");

	return (
		<div className="border-y   p-2">
			<div className="lg:text-center max-w-xl mx-auto mb-4">
				<motion.h4
					initial={{ opacity: 0, x: -100 }}
					whileInView={{ opacity: 1, x: 0 }}
					viewport={{ once: true }}
					transition={{ duration: 0.5 }}
					className="text-stone-700 mb-3 text-3xl lg:text-4xl font-bold"
				>
					{t("subtitle2")}
				</motion.h4>
				<motion.p
					initial={{ opacity: 0, x: -100 }}
					whileInView={{ opacity: 1, x: 0 }}
					viewport={{ once: true }}
					transition={{ duration: 0.5 }}
					className="text-gray-500 text-sm lg:text-base"
				>
					{t("paragraph1")}
				</motion.p>
			</div>
			<div className="flex text-gray-600 flex-wrap justify-center gap-12">
				<motion.div
					initial={{ opacity: 0, x: -100 }}
					whileInView={{ opacity: 1, x: 0 }}
					viewport={{ once: true }}
					transition={{ duration: 0.5 }}
					className="flex   p-4  text-center max-w-lg gap-3 items-center"
				>
					<MdSecurity size={40} className="text-primary/70" />
					<div>
						<h4 className="text-2xl text-primary/70 font-bold">{t("item1")}</h4>
					</div>
				</motion.div>
				<motion.div
					initial={{ opacity: 0, y: -40 }}
					whileInView={{ opacity: 1, y: 0 }}
					viewport={{ once: true }}
					transition={{ duration: 0.5 }}
					className="flex  p-4   text-center max-w-lg gap-3 items-center"
				>
					<IoCheckmarkDone size={40} className="text-primary/70" />
					<div>
						<h4 className="text-2xl text-primary/70 font-bold">{t("item2")}</h4>
					</div>
				</motion.div>
				<motion.div
					initial={{ opacity: 0, x: 100 }}
					whileInView={{ opacity: 1, x: 0 }}
					viewport={{ once: true }}
					transition={{ duration: 0.5 }}
					className="flex p-4  text-center max-w-lg gap-3 items-center"
				>
					<BiTimer size={40} className="text-primary/70" />
					<div>
						<h4 className="text-2xl text-primary/70 font-bold">{t("item3")}</h4>
					</div>
				</motion.div>
			</div>
		</div>
	);
}

export default Caracteristicas;
