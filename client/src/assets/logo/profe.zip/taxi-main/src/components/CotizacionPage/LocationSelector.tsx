import { useState, useRef } from "react";

import InputAutocomplete from "./InputAutocomplete";
import Image from "next/image";

import { IoIosArrowBack } from "react-icons/io";

import FormReserva from "./FormReserva";
import { FaMapMarkerAlt, FaSuitcaseRolling, FaUsers } from "react-icons/fa";
import { useRouter } from "next/router";
import Input from "./Input";
import { useSnackbar } from "notistack";
import Select from "@components/ui/forms/Select";
import Vehiculos from "./Vehiculos";
import SimpleInput from "@components/ui/forms/SimpleInput";
import busImage from "../../../public/cars/bus.png";
import confortImage from "../../../public/cars/confort.png";
import standarImage from "../../../public/cars/standar.png";
import exclusivoImage from "../../../public/cars/exclusivo.png";
import premiumImage from "../../../public/cars/premium.png";
import urbanImage from "../../../public/cars/urban.png";
import vanImage from "../../../public/cars/van.png";
import { BsFillCreditCardFill } from "react-icons/bs";
import { GiReceiveMoney } from "react-icons/gi";
import { useTranslation } from "next-i18next";

type Vehicle = {
	name: string;
	description: string;
	minPrice: number;
	image: string;
	price: number;
	contactar: false;
	capacity: number;
	maletas: number;
};

function LocationSelector({
	setDirectionsResponse,
	setSelectedLocation,
	setSelectedLocationOrigin,
}: {
	setDirectionsResponse: any;
	setSelectedLocation: any;
	setSelectedLocationOrigin: any;
}) {
	const { enqueueSnackbar } = useSnackbar();
	const [isFocused, setIsFocused] = useState("from");
	const [distance, setDistance] = useState("");
	const [isReservation, setIsReservation] = useState(false);
	const [typeVehicle, setTypeVehicle] = useState<Vehicle | null>(null);
	const [duration, setDuration] = useState("");
	const [typePayment, setTypePayment] = useState("");
	const [step, setStep] = useState(0);
	const originRef = useRef() as any;
	const router = useRouter();
	const destiantionRef = useRef() as any;
	const nombreRef = useRef() as any;
	const phoneRef = useRef() as any;
	const { t } = useTranslation("main");

	const calculatePrice = (
		minPrice: number,
		distance: number,
		price: number,
		originValue: string,
		destinationValue: string
	) => {
		const isAeroport =
			/aeropuerto/i.test(originValue) || /aeropuerto/i.test(destinationValue);

		let priceBase = (distance * price).toFixed(2);

		if (router.query.service == "Servicio courier") {
			priceBase += 10;
		}

		if (minPrice > +priceBase) {
			return (minPrice + (isAeroport ? 15 : 0)).toFixed(2);
		}
		if (isAeroport) {
			return +priceBase + 15;
		}
		return +priceBase;
	};

	async function calculateRoute() {
		if (originRef.current.value === "") {
			enqueueSnackbar("Ingrese la ubicación de origen.", {
				variant: "error",
			});
			originRef.current.focus();
			return;
		}
		if (destiantionRef.current.value === "") {
			enqueueSnackbar("Ingrese la ubicación de destino.", {
				variant: "error",
			});
			destiantionRef.current.focus();
			return;
		}

		// eslint-disable-next-line no-undef
		const directionsService = new google.maps.DirectionsService();

		const results = (await directionsService.route({
			origin: originRef.current.value,
			destination: destiantionRef.current.value,
			// eslint-disable-next-line no-undef
			travelMode: google.maps.TravelMode.DRIVING,
		})) as any;

		setDirectionsResponse(results);
		if (results) {
			setDistance(results.routes[0].legs[0].distance.text);
			setDuration(results.routes[0].legs[0].duration.text);
		}
	}

	const listo = async (type: string) => {
		if (!typeVehicle) {
			return;
		}
		// const price =
		// 	typeVehicle.minPrice! > +(+distance * typeVehicle.price).toFixed(2)
		// 		? typeVehicle.minPrice
		// 		: +(+distance * typeVehicle.price!).toFixed(2);
		const price = calculatePrice(
			typeVehicle.minPrice!,
			parseFloat(distance),
			typeVehicle.price!,
			originRef.current.value,
			destiantionRef.current.value
		);

		if (type === "ahora") {
			window.open(
				`https://wa.me/51960607020?text=Hola+soy+${
					nombreRef.current.value
				}%0ADe%3A+${
					originRef.current.value
				}%0ATarifa%3A+S/${price}%0D%0AHacia%3A+${
					destiantionRef.current.value
				}%0D%0ACategor%C3%ADa%3A+${typeVehicle.name}%0AServicio%3A+${
					router.query.service || "Solo Ida"
				}%0D%0APago%3A+${typePayment.toUpperCase()}`,
				"_blank",
				"noopener noreferrer"
			);
			return;
		}
		setIsReservation(true);
	};

	return (
		<div className="pt-2 px-2 sm:px-5 w-screen contenedor md:w-[600px] max-h-[500px]  overflow-y-auto p-2 rounded-3xl lg:rounded-xl shadow-2xl bg-white  ">
			<div className={`${step !== 0 && "hidden"}`}>
				<h4 className="text-2xl font-bold text-stone-700 text-center my-3">
					{isFocused === "from" && t("title-travel2")}
					{isFocused === "to" && t("title-travel3")}
					{isFocused === "" && t("title-travel")}
				</h4>
				<div className="flex flex-col mb-4 relative ">
					<div className="relative">
						<div className="top-6  text-primary left-3 absolute">
							<FaMapMarkerAlt size={18} className="" />
						</div>
						<InputAutocomplete
							refInput={originRef}
							setPointer={setSelectedLocationOrigin}
							placeholder={t("youlocation")}
							setIsFocused={setIsFocused}
						/>
					</div>
					<div className="relative">
						<div className="top-6   text-primary left-3 absolute">
							<FaMapMarkerAlt size={18} className="" />
						</div>
						<InputAutocomplete
							setPointer={setSelectedLocation}
							refInput={destiantionRef}
							placeholder={t("youdestination")}
							setIsFocused={setIsFocused}
						/>
					</div>
				</div>
			</div>
			<div className={`${step !== 2 && "hidden"}`}>
				<h4 className="text-2xl font-bold text-stone-700 text-center mb-3">
					{t("title-travel4")}
				</h4>
				<div className="flex flex-col gap-4 mb-4">
					<SimpleInput label={t("youname")} refInput={nombreRef} type="text" />
					<SimpleInput
						label={t("youphone")}
						refInput={phoneRef}
						type="number"
					/>
				</div>
			</div>
			{step === 1 && (
				<>
					<h4 className="text-2xl font-bold text-stone-700 text-center mb-3">
						{t("title-travel5")}
					</h4>
					<Vehiculos
						typeVehicle={typeVehicle}
						setTypeVehicle={setTypeVehicle}
						origin={originRef.current.value}
						destination={destiantionRef.current.value}
						distance={parseFloat(distance)}
					/>
				</>
			)}
			{step === 3 && (
				<>
					<h4 className="text-2xl font-bold text-stone-700 text-center mb-3">
						{t("title-travel6")}
					</h4>
					<div className="flex flex-col gap-4 mb-4">
						<div className="flex">
							<div
								onClick={() => setTypePayment("efectivo")}
								className={`${
									typePayment === "efectivo"
										? "bg-gradient-to-r from-primary via-blue-500 to-primary text-white"
										: "bg-white text-primary"
								} rounded-l-lg flex justify-center cursor-pointer items-center border-primary border   text-primary p-2 w-full`}
							>
								<GiReceiveMoney size={100} />
								{t("cash")}
							</div>
							<div
								onClick={() => setTypePayment("tarjeta")}
								className={`${
									typePayment === "tarjeta"
										? "bg-gradient-to-r from-primary via-blue-500 to-primary text-white"
										: "bg-white text-primary"
								} rounded-r-lg border-primary cursor-pointer border flex gap-3 justify-center items-center  text-primary p-2 w-full`}
							>
								<BsFillCreditCardFill size={80} />
								{t("card")}
							</div>
						</div>
					</div>
				</>
			)}
			{step === 4 ? (
				<>
					<h4 className="text-2xl font-bold text-stone-700 text-center mb-3">
						{t("title-travel7")}
					</h4>
					<div className="flex text-gray-500 flex-col gap-4 mb-4">
						<div className="flex flex-col gap-2">
							<p>
								<strong>{t("origin-text")}: </strong>
								{originRef.current.value}
							</p>
							<p>
								<strong>{t("destination-text")}: </strong>
								{destiantionRef.current.value}
							</p>
							<p>
								<strong>{t("typevehicle-text")}: </strong>
							</p>
							<p>
								<strong>{t("distance-text")}: </strong>
								{distance}
							</p>
							<div
								className={`w-11/12 cursor-pointer rounded-md hover:scale-105 duration-300 text-gray-500 items-center flex justify-between py-2 px-4 border`}
							>
								<div className="flex flex-col items-center text-xs">
									<div className="relative w-28 h-20 md:w-36 md:h-24">
										<Image
											alt={typeVehicle?.name || ""}
											src={typeVehicle?.image || ""}
											fill
										/>
									</div>

									<p className="text-xs">{typeVehicle?.description}</p>
								</div>
								<div className="flex flex-col text-center items-center">
									<h6 className="font-bold text-xs sm:text-sm md:text-base">
										{typeVehicle?.name}
									</h6>
								</div>
								<div className="flex flex-col md:flex-row md:gap-12 px-3 gap-1 items-center">
									<div className="flex flex-col items-center gap-2">
										<span>
											S/
											{calculatePrice(
												typeVehicle?.minPrice!,
												parseFloat(distance),
												typeVehicle?.price!,
												originRef.current.value,
												destiantionRef.current.value
											)}
										</span>

										<div className="flex gap-3 items-center">
											<p className="text-xs flex items-center gap-1">
												<FaUsers size={15} />
												{typeVehicle?.capacity}{" "}
												<span className="hidden sm:block">Max</span>
											</p>
											<p className="text-xs flex items-center gap-1">
												<FaSuitcaseRolling size={15} />
												{typeVehicle?.maletas}
												<span className="hidden sm:block">Max</span>
											</p>
										</div>
									</div>
								</div>
							</div>

							<p className="capitalize">
								<strong>{t("methodpayment-text")}: </strong>
								{typePayment}
							</p>
						</div>
					</div>
					<div className="w-full p-2">
						<div className="flex gap-4 justify-between">
							<button
								onClick={() => listo("reserva")}
								className="rounded-lg border hover:shadow-lg text-primary border-primary p-2 w-1/2"
							>
								{t("reserve-btn")}
							</button>
							<button
								onClick={() => listo("ahora")}
								className="rounded-lg text-white hover:shadow-lg bg-gradient-to-r from-primary via-blue-500 to-primary p-2 w-1/2"
							>
								{t("for-now")}
							</button>
						</div>
					</div>
					{isReservation && (
						<FormReserva
							tipoPago={typePayment}
							telefono={phoneRef.current.value}
							nombre={nombreRef.current.value}
							destino={destiantionRef.current.value}
							origen={originRef.current.value}
							distance={distance}
							duracion={duration}
							typeVehicle={typeVehicle}
						/>
					)}
				</>
			) : (
				<div className="w-full p-2">
					<div className="flex gap-4 justify-between">
						{step >= 1 && (
							<button
								onClick={() => setStep(step - 1)}
								className="rounded-lg   hover:shadow-lg duration-300 hover:scale-105 btn-outline p-2 w-full"
							>
								{t("enter-back")}
							</button>
						)}
						<button
							onClick={() => {
								if (step == 0) {
									if (
										originRef.current.value === "" ||
										destiantionRef.current.value === ""
									) {
										enqueueSnackbar(
											"Por favor ingrese su localización y destino",
											{
												variant: "error",
											}
										);
										return;
									} else {
										calculateRoute();
									}
								}

								if (step == 2) {
									if (
										phoneRef.current.value < 9 ||
										nombreRef.current.value === ""
									) {
										enqueueSnackbar("Por favor ingrese su nombre y telefono", {
											variant: "error",
										});
										return;
									}
								}

								if (step == 1) {
									if (!typeVehicle) {
										enqueueSnackbar(
											"Por favor seleccione un tipo de vehiculo",
											{
												variant: "error",
											}
										);
										return;
									}
								}
								if (step == 3) {
									if (typePayment === "") {
										enqueueSnackbar("Seleccione un metodo de pago", {
											variant: "error",
										});
										return;
									}
								}

								setStep(step + 1);
							}}
							className="rounded-lg text-white hover:shadow-lg duration-300 hover:scale-105 bg-gradient-to-r from-primary via-blue-500 to-primary p-2 w-full"
						>
							{t("enter-next")}
						</button>
					</div>
				</div>
			)}
		</div>
	);
}

export default LocationSelector;
