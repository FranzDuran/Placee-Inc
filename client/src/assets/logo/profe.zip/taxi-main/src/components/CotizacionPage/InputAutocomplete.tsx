import { Autocomplete } from "@react-google-maps/api";
import { useState } from "react";

function InputAutocomplete({
	setIsFocused,
	placeholder,
	setPointer,
	refInput,
}: {
	setIsFocused: any;
	placeholder: string;
	setPointer?: any;
	refInput: any;
}) {
	const [inputValue, setInputValue] = useState("");

	return (
		<Autocomplete
			className="w-full"
			onPlaceChanged={async () => {
				setInputValue(refInput.current.value);

				try {
					const rta = (await new window.google.maps.Geocoder().geocode({
						address: refInput.current.value,
					})) as any;
					if (!rta) return;

					if (!setPointer) return;

					setPointer(
						rta.results[0].geometry.location.lat(),
						rta.results[0].geometry.location.lng()
					);
				} catch (error) {
					console.log(error);
				}
			}}
			restrictions={{
				country: ["pe"],
			}}
		>
			<input
				ref={refInput}
				value={inputValue}
				onChange={(e) => setInputValue(e.target.value)}
				// onFocus={() =>
				// 	setIsFocused(
				// 		["Tu ubicación", "Your location"].includes(placeholder)
				// 			? "to"
				// 			: "from"
				// 	)
				// }
				className="my-2 rounded-md outline-primary focus:border-primary focus:ring-primary shadow-md border py-3 px-12 w-full"
				placeholder={placeholder}
			/>
		</Autocomplete>
	);
}

export default InputAutocomplete;
