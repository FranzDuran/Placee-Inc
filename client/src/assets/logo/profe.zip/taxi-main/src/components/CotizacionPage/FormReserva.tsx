import React from "react";
import { Formik, Form } from "formik";

import axios from "axios";
import { useSnackbar } from "notistack";

import { useRouter } from "next/router";
import LoadingSubmit from "@components/ui/loadings/LoadingSubmit";
import { useTranslation } from "next-i18next";
import Swal from "sweetalert2";
import withReactContent from "sweetalert2-react-content";
type Vehicle = {
	name: string;
	description: string;
	minPrice: number;
	image: string;
	price: number;
	contactar: false;
	capacity: number;
	maletas: number;
};

const MySwal = withReactContent(Swal);
function FormReserva({
	origen,
	destino,
	duracion,
	distance,
	nombre,
	typeVehicle,
	telefono,
	tipoPago,
}: {
	origen: string;
	destino: string;
	duracion: string;
	nombre: string;
	distance: string;
	telefono: string;
	tipoPago: string;
	typeVehicle: Vehicle | null;
}) {
	const { enqueueSnackbar } = useSnackbar();
	const enviarCotizacion = async (values: any) => {
		try {
			const body = {
				origen,
				destino,
				duracion,
				tipo: typeVehicle?.name,
				distancia: distance,
				nombre,
				tipoPago,
				fecha: values.fecha,
				telefono,
			};

			const rta = await axios.post("/api/reservation", body, {
				headers: {
					"Content-Type": "application/json",
				},
			});

			if (rta.status === 200) {
				MySwal.fire({
					icon: "success",
					html: "<p>Tu reserva fue registrada con éxito, dentro de poco un asesor se contactará contigo para confirmar su reserva.</p>",
					confirmButtonColor: "#095EB9",

					allowOutsideClick: false,
					confirmButtonText: "Ok",
				});
				return;
			}
			enqueueSnackbar(
				"Hubo un error al enviar la reserva, comunicate por wsp.",
				{
					variant: "error",
					autoHideDuration: 3000,
				}
			);
		} catch (error) {
			enqueueSnackbar(
				"Hubo un error al enviar la reserva, comunicate por wsp.",
				{
					variant: "error",
					autoHideDuration: 3000,
				}
			);
		}
	};

	const { t } = useTranslation("main");

	return (
		<div className="w-full">
			<Formik
				initialValues={{
					fecha: "",
				}}
				onSubmit={async (values, { setSubmitting, resetForm }) => {
					if (!values.fecha) {
						enqueueSnackbar(
							"Debe seleccionar una fecha y hora para la reserva.",
							{
								variant: "error",
							}
						);
					}
					setSubmitting(true);
					await enviarCotizacion(values);
					setSubmitting(false);
				}}
			>
				{({ isSubmitting, errors, handleBlur, touched, setFieldValue }) => (
					<Form className="flex flex-col gap-2">
						<p className="text-gray-600 font-bold text-lg py-3">
							{t("fecha-text")}
						</p>

						<div className="flex mt-2 flex-col w-full">
							<input
								type="datetime-local"
								name="fecha"
								lang="es"
								min={new Date().toISOString().split("T")[0]}
								onChange={(e) => {
									setFieldValue("fecha", e.target.value);
								}}
								className="appearance-none border border-gray-200 shadow w-full rounded focus:ring-0 focus:border-none py-3 px-3 text-gray-500 leading-tight focus:outline-none focus:shadow-outline"
							/>
						</div>
						<button
							type="submit"
							className="rounded-lg mt-3 relative text-white hover:shadow-lg bg-gradient-to-r from-primary via-blue-500 to-primary p-2 w-full"
							disabled={isSubmitting}
						>
							{isSubmitting ? <LoadingSubmit /> : t("send-btn")}
						</button>
					</Form>
				)}
			</Formik>
		</div>
	);
}

export default FormReserva;
