import React from "react";
import styles from "./input.module.css";
import { Field } from "formik";

type InputProps = {
	type: string;
	label: string;

	refInput: any;
};

function SimpleInput({ type, label, refInput }: InputProps) {
	return (
		<div className="">
			<div className={styles.containerInput}>
				<input
					type={type}
					ref={refInput}
					id={label}
					placeholder=" "
					translate="no"
					className={
						styles.inputCustom +
						"  text-gray-600  focus:ring-0 focus:outline-none border-gray-200 focus:border-primary/60 border-b-2  "
					}
				/>
				<label htmlFor={label} className={styles.labelInput}>
					{label}
				</label>
			</div>
		</div>
	);
}

export default SimpleInput;
