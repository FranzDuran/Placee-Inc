import React from "react";
import { HiBars2, HiXMark } from "react-icons/hi2";
import { Menu, Transition } from "@headlessui/react";
import { Fragment } from "react";
import { useTranslation } from "next-i18next";
import Link from "next/link";

function BarIcon() {
	const [open, setOpen] = React.useState(false);
	const { t } = useTranslation("common");

	return (
		<Menu as={Fragment}>
			<Menu.Button onClick={() => setOpen(!open)} className="">
				<HiBars2 className="w-8 h-8 lg:hidden" />
			</Menu.Button>
			<Transition
				as={Fragment}
				show={open}
				enter="transition ease-out duration-100 transform"
				enterFrom="transform opacity-0 scale-95 -translate-y-1 md:translate-y-1"
				enterTo="transform opacity-100 scale-100 translate-y-0"
				leave="transition ease-in duration-75 transform"
				leaveFrom="transform opacity-100 scale-100 translate-y-0"
				leaveTo="transform opacity-0 scale-95 -translate-y-1 md:translate-y-1"
			>
				<Menu.Items className="fixed z-[50] right-0 bg-white px-3 text-xl top-0 border-gray-200 text-black border  w-3/4 origin-top-right divide-y divide-gray-100 h-full  shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
					<div className="p-1 flex flex-col gap-5">
						<div className="p-3 flex justify-between items-center">
							<span className=" font-bold  ">MENU</span>
							<HiXMark
								className="w-8 h-8 absolute right-0 top-0 m-4 cursor-pointer"
								onClick={() => setOpen(false)}
							/>
						</div>

						<div className="flex flex-col gap-10">
							<Link href="/" className="">
								{t("home")}
							</Link>
							<Link href="/nosotros">{t("about")}</Link>
							<Link href="/servicios">{t("services")}</Link>
							<Link href="/empresas">{t("companies")}</Link>
						</div>
						<Link href="/viajar" className="btn px-4 py-2 text-center">
							{t("letstravel")}
						</Link>
					</div>
				</Menu.Items>
			</Transition>
		</Menu>
	);
}

export default BarIcon;
