import { useState } from "react";
import { useSnackbar } from "notistack";
import { IoMdLocate } from "react-icons/io";

function ObtenerUbicacion({
	setSelectedLocation,
}: {
	setSelectedLocation: any;
}) {
	const { enqueueSnackbar } = useSnackbar();

	const handleClick = () => {
		if (navigator.geolocation) {
			// eslint-disable-next-line no-undef
			navigator.geolocation.getCurrentPosition(
				(position) => {
					if (!position) return;
					setSelectedLocation(
						position.coords.latitude,
						position.coords.longitude
					);
				},
				() => {
					alert("No se pudo obtener su ubicación");
				}
			);
		} else {
			enqueueSnackbar("Tu navegador no soporta la geolocalización", {
				variant: "error",
			});
		}
	};

	return (
		<div
			onClick={handleClick}
			className="bg-gray-50 shadow top-3.5 cursor-pointer right-3 absolute p-2 rounded-full"
		>
			<IoMdLocate size={20} className="text-primary" />
		</div>
	);
}

export default ObtenerUbicacion;
