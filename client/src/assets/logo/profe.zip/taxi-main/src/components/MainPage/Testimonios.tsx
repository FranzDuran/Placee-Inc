import { useEffect, useRef, useState } from "react";
import TestimonioCard from "./TestimonioCard";
import { BsChevronLeft, BsChevronRight } from "react-icons/bs";

//TESTIMONIOS IMAGES
import image1 from "../../../public/testimonios/1.jpg";
import image2 from "../../../public/testimonios/2.jpg";
import image3 from "../../../public/testimonios/3.jpg";
import image4 from "../../../public/testimonios/4.jpg";
import image5 from "../../../public/testimonios/5.png";
import image6 from "../../../public/testimonios/6.png";

import { useRouter } from "next/router";

const testimoiosList = [
	{
		name: "Guiisel Salas",
		description:
			"Me ofrecieron un buen servicio, muy recomendable para traslados al aeropuerto.",
		image: image1,
	},
	{
		name: "Angelica Cordozo",
		description: "Muy buen servicio, puntual y con excelente atención.",
		image: image2,
	},
	{
		name: "Leon Jhon",
		description:
			"Dios los bendiga muchísimo. me gusto muchisimo su forma de trabajar.",
		image: image3,
	},
	{
		name: "Teresa Shanahan",
		description:
			"Es excelente el servicio que me brindaron. Súper recomendables. Muchas gracias, voy a compartir sus datos con amigos",
		image: image4,
	},
	{
		name: "Carlos Valladares",
		description:
			"Excelente experiencia. Puntualidad y buen servicio, siempre atentos a consultas y requerimientos",
		image: image5,
	},
	{
		name: "Servitdesk Infraestructura",
		description: "Excelente servicio, puntual, confiable y amable",
		image: image6,
	},
];

const testimoniosEnglishList = [
	{
		name: "Guiisel Salas",
		description:
			"They offered me a good service, highly recommended for airport transfers.",
		image: image1,
	},
	{
		name: "Angelica Cordozo",
		description: "Very good service, punctual and with excellent attention.",
		image: image2,
	},
	{
		name: "Leon Jhon",
		description: "God bless you very much. I really like his way of working.",
		image: image3,
	},
	{
		name: "Teresa Shanahan",
		description:
			"The service they provided me is excellent. Super recommended. Thank you very much, I will share your data with friends",
		image: image4,
	},
	{
		name: "Carlos Valladares",
		description:
			"Excellent experience. Punctuality and good service, always attentive to queries and requirements",
		image: image5,
	},
	{
		name: "Servitdesk Infraestructura",
		description: "Excellent service, punctual, reliable and friendly",
		image: image6,
	},
];

function TestimonioList() {
	const [scroll, setScroll] = useState(0);
	const [mounted, setMounted] = useState(false);
	const element = useRef(null) as any;
	const router = useRouter();

	useEffect(() => {
		if (!mounted) {
			setMounted(true);
			return;
		}
		setScroll(element.current.scrollLeft);
	}, [mounted]);

	const scrollLeft = () => {
		element.current.scrollLeft -= 500;
		setScroll(element.current.scrollLeft);
	};

	const scrollRight = () => {
		element.current.scrollLeft += 500;
		setScroll(element.current.scrollLeft);
	};

	return (
		<div className="scrollbar-hide ">
			<div
				ref={element}
				className="flex scroll-smooth justify-center gap-4 overflow-x-scroll scrollbar-hide p-3"
			>
				{router.locale === "es"
					? testimoiosList.map((item) => (
							<TestimonioCard item={item} key={item.name} />
					  ))
					: testimoniosEnglishList.map((item) => (
							<TestimonioCard item={item} key={item.name} />
					  ))}
			</div>
			<div className="flex gap-4 mb-3 justify-center text-gray-500">
				<div
					onClick={scrollLeft}
					className={`rounded-full p-3 cursor-pointer bg-white hover:bg-gray-50 shadow-md ${
						scroll > 0 ? "" : "hidden"
					}`}
				>
					<BsChevronLeft className="w-7 h-7  " />
				</div>
				<div
					onClick={scrollRight}
					className={`rounded-full p-3 cursor-pointer bg-white hover:bg-gray-50 shadow-md ${
						element?.current?.scrollWidth - element?.current?.scrollLeft >
						element?.current?.clientWidth
							? ""
							: "hidden"
					}`}
				>
					<BsChevronRight className="w-7 h-7" />
				</div>
			</div>
		</div>
	);
}

export default TestimonioList;
