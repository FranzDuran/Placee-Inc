import React from "react";
import Spinner from "react-loading";

function ButtonSubmit({ loading, text }: { loading: boolean; text: string }) {
	return (
		<button type="submit" className="btn p-2 flex justify-center items-center">
			{loading ? (
				<Spinner type="spin" color="white" width={15} height={15} />
			) : (
				text
			)}
		</button>
	);
}

export default ButtonSubmit;
