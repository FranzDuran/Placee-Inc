import React from "react";
import { Formik, Form, Field } from "formik";

import InputField from "../ui/forms/InputField";

import axios from "axios";
import { useSnackbar } from "notistack";
import { datosPresupuestoSchema } from "@schemas";

import LoadingSubmit from "@components/ui/loadings/LoadingSubmit";
import Select from "@components/ui/forms/Select";
import { useTranslation } from "next-i18next";

function FormPresupuesto() {
	const { enqueueSnackbar } = useSnackbar();
	const { t } = useTranslation("companies");
	const solicitarUnion = async (values: any) => {
		try {
			const body = {
				...values,
				ruc: values.ruc.toString(),
				telefono: values.telefono.toString(),
			};

			const rta = await axios.post("/api/presupuesto", body, {
				headers: {
					"Content-Type": "application/json",
				},
			});

			if (rta.status === 200) {
				enqueueSnackbar(
					"Petición de presupuesto enviada con éxito dentro de poco se le contactará.",
					{
						variant: "success",
						autoHideDuration: 4000,
					}
				);
				return;
			}
			enqueueSnackbar(
				"Hubo un error al enviar su petición, comunicate por WhatsApp.",
				{
					variant: "error",
					autoHideDuration: 3000,
				}
			);
		} catch (error) {
			enqueueSnackbar(
				"Hubo un error al enviar su petición, comunicate por WhatsApp.",
				{
					variant: "error",
					autoHideDuration: 3000,
				}
			);
		}
	};

	return (
		<div className="w-full">
			<Formik
				initialValues={{
					telefono: "",
					cantidadEmpleados: "",
					empresa: "",
					email: "",
					nombres: "",
					ruc: "",
				}}
				validationSchema={datosPresupuestoSchema}
				onSubmit={async (values, { setSubmitting, resetForm }) => {
					setSubmitting(true);
					await solicitarUnion(values);
					resetForm();
					setSubmitting(false);
				}}
			>
				{({
					isSubmitting,
					errors,
					handleBlur,
					touched,
					setFieldValue,
					values,
				}) => (
					<Form className="flex flex-col gap-2">
						<InputField
							isError={errors.nombres}
							label={t("placeholder1")}
							name="nombres"
							type="text"
							handleBlur={handleBlur}
							touched={touched.nombres}
						/>
						<InputField
							isError={errors.telefono}
							label={t("placeholder2")}
							name="telefono"
							type="number"
							handleBlur={handleBlur}
							touched={touched.telefono}
						/>
						<InputField
							isError={errors.email}
							label="Email"
							name="email"
							type="email"
							handleBlur={handleBlur}
							touched={touched.email}
						/>
						<InputField
							isError={errors.empresa}
							label={t("placeholder3")}
							name="empresa"
							type="text"
							handleBlur={handleBlur}
							touched={touched.empresa}
						/>
						<InputField
							isError={errors.ruc}
							label="RUC"
							name="ruc"
							type="number"
							handleBlur={handleBlur}
							touched={touched.ruc}
						/>
						<Select
							isError={errors.cantidadEmpleados}
							items={["1 - 20", "20 - 100", "+100"]}
							label={t("placeholder4")}
							setFieldValue={(val: string) =>
								setFieldValue("cantidadEmpleados", val)
							}
							touched={touched.cantidadEmpleados}
							value={values.cantidadEmpleados}
						/>

						<button
							type="submit"
							className="rounded-lg mt-3 text-white hover:shadow-lg duration-300 hover:scale-105 bg-gradient-to-r from-primary via-blue-500 to-primary p-2 w-full"
							disabled={isSubmitting}
						>
							{isSubmitting ? <LoadingSubmit /> : "Enviar"}
						</button>
					</Form>
				)}
			</Formik>
		</div>
	);
}

export default FormPresupuesto;
