import { motion } from "framer-motion";
import { useState } from "react";
import { useTranslation } from "next-i18next";
import Select from "@components/ui/forms/Select";
import { useRouter } from "next/router";

const services = [
	{
		title: "Airpoort - Traslado al aeropuerto",
		description:
			"Ofrecemos servicios de traslado al aeropuerto para nuestros clientes VIP, asegurándonos de que lleguen a tiempo y de manera segura a su destino.",
	},
	{
		title: "Servicio de taxi seguro.",
		description:
			"Ofrecemos servicios de taxi seguros para nuestros clientes, asegurándonos de que lleguen a su destino de manera segura y cómoda.",
	},
	{
		title: "Traslados para eventos",
		description:
			"Ofrecemos servicios de traslado para eventos especiales, como bodas, reuniones de negocios, conciertos, entre otros.",
	},
	{
		title: "Servicios de chofer personal",
		description:
			"Ofrecemos servicios de chofer personal para nuestros clientes VIP, proporcionando un conductor profesional y altamente capacitado para atender sus necesidades de transporte",
	},
	{
		title: "Tours de ciudad",
		description:
			"Ofrecemos tours de ciudad personalizados para nuestros clientes VIP, brindando una experiencia única para conocer los lugares más emblemáticos de nuestra ciudad.",
	},
	{
		title: "Servicio courier",
		description:
			"Ofrecemos servicios de courier para nuestros clientes, brindando soluciones personalizadas para sus necesidades de transporte.",
	},
	{
		title: "Transporte corporativo - Facturado",
		description:
			"Ofrecemos servicios de transporte corporativo para empresas, brindando soluciones personalizadas para sus necesidades de transporte.",
	},
];

function CotizarContainer() {
	const router = useRouter();
	const { t } = useTranslation("main");

	const [serviceSelected, setServiceSelected] = useState("");

	return (
		<motion.div
			initial={{ opacity: 0, y: -40 }}
			animate={{ opacity: 1, y: 0 }}
			transition={{ duration: 0.5 }}
			className="bg-white shadow-xl rounded-lg flex flex-col justify-center p-5 max-h-[320px] min-h-[220px] xl:min-h-[310px] overflow-y-auto containerCotizacion contenedor w-full max-w-2xl"
		>
			<h3 className="text-3xl font-bold">{t("title-travel")}</h3>
			<p className="text-gray-500 text-sm pb-2">{t("parragraph-viajar")}</p>
			<Select
				isError={false}
				items={services.map((i) => i.title)}
				label="Tipo de servicio"
				setFieldValue={(val: string) => {
					setServiceSelected(val);
				}}
				touched={false}
				value={serviceSelected}
			/>
			{serviceSelected.length > 0 && (
				<>
					<p className="text-gray-600 text-sm p-3">
						{services.find((i) => i.title === serviceSelected)?.description}
					</p>
					<div className="flex justify-end items-center">
						<button
							onClick={() => router.push(`/viajar/?service=${serviceSelected}`)}
							className="btn hover:scale-105 duration-300 rounded-md px-4 w-1/2 py-3 mt-4"
						>
							{t("text-viajar")}
						</button>
					</div>
				</>
			)}
		</motion.div>
	);
}

export default CotizarContainer;
