import { useState } from "react";
import Navbar from "../Navigation/Navbar";
import classNames from "classnames";

function Header() {
	const [isSticky, setIsSticky] = useState(false);

	const setObservedNode = (node: HTMLElement | null) => {
		if (node) {
			const observer = new IntersectionObserver(
				(entries) => {
					entries.forEach((entry) => {
						if (entry.isIntersecting) {
							setIsSticky(false);
						} else {
							setIsSticky(true);
						}
					});
				},
				{
					threshold: 1,
				}
			);
			observer.observe(node);
		}
	};

	return (
		<header
			className={classNames(
				"z-50 sticky w-full  -top-px text-white  bg-black/40   transition-shadow  ",
				{
					"shadow-md !text-stone-800  !bg-white   ": isSticky,
				}
			)}
			ref={setObservedNode}
		>
			<Navbar isSticky={isSticky} />
		</header>
	);
}

export default Header;
