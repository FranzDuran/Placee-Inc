import React from "react";
import Logo from "../Logo";
import Image from "next/image";
import LogoColor from "../../../public/icon-color.png";
import Link from "next/link";
import { useRouter } from "next/router";
import { BsWhatsapp } from "react-icons/bs";
import BarIcon from "./BarIcon";
import { useTranslation } from "next-i18next";
import ChangeCountry from "./ChangeCountry";

function Navbar({ isSticky }: { isSticky: boolean }) {
	const router = useRouter();
	const { t } = useTranslation("common");
	return (
		<div className="p-3   max-w-7xl mx-auto w-full   lg:px-24 flex items-center justify-between">
			<Link href="/">
				<div className="flex hover:scale-105 duration-300 items-center cursor-pointer text-2xl font-extrabold">
					<span className="flex items-center relative">
						{isSticky ? (
							<div className="overflow-hidden h-5 w-4 mr-0.5 relative">
								<Image
									src={LogoColor}
									alt="Picture of the author"
									className=""
									fill
								/>
							</div>
						) : (
							<Logo />
						)}
						<span
							className={`pl-0 ${isSticky && "text-primary"}`}
							translate="no"
						>
							erocab
						</span>
					</span>
				</div>
			</Link>
			<div>
				<ul className="hidden lg:flex gap-6 font-medium items-center">
					<Link
						href="/"
						className="hover:opacity-50 cursor-pointer duration-300 transition-opacity"
					>
						{t("home")}
					</Link>

					<Link
						href="/nosotros"
						className="hover:opacity-50 cursor-pointer duration-300 transition-opacity"
					>
						{t("about")}
					</Link>
					<Link
						href="/servicios"
						className="hover:opacity-50 cursor-pointer duration-300 transition-opacity"
					>
						{t("services")}
					</Link>
					<Link
						href="/empresas"
						className="hover:opacity-50 cursor-pointer duration-300 transition-opacity"
					>
						{t("companies")}
					</Link>

					{router.pathname == "/viajar" ? (
						<Link
							href="https://wa.me/51960607020?text=Hola%20quiero%20viajar"
							target="_blank"
							className="transition-all duration-200 hover:scale-95 transform flex items-center gap-1 btn-outline cursor-pointer px-4 py-2"
						>
							<BsWhatsapp size={20} />
							{t("writeus")}
						</Link>
					) : (
						<Link
							href="/viajar"
							className="hover:opacity-60 btn cursor-pointer duration-300 transition-opacity px-4 py-2"
						>
							{t("letstravel")}
						</Link>
					)}
				</ul>
			</div>
			<div className="flex gap-3 px-2 items-center">
				<ChangeCountry />

				<BarIcon />
			</div>
		</div>
	);
}

export default Navbar;
