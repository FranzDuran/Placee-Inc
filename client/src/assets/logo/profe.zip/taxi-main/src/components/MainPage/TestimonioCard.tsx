import Image from "next/image";
import React, { memo } from "react";
import { FaQuoteLeft } from "react-icons/fa";

type TestimonioType = {
	name: string;
	description: string;
	image: any;
};

function TestimonioCard({ item }: { item: TestimonioType }) {
	return (
		<div className="bg-white max-w-[450px] relative min-w-[400px] rounded-lg shadow-lg p-4">
			<div className="bg-white absolute shadow-md right-4 top-[-12px] rounded-full p-3 flex items-center justify-center text-primary">
				<FaQuoteLeft className="w-5 h-5" />
			</div>
			<div className="flex items-center gap-4">
				<div className="h-12 w-12 relative">
					<Image
						src={item.image}
						alt="testimonio"
						fill
						loading="lazy"
						className="rounded-full blur-[1px] object-cover object-center"
					/>
				</div>
				<div>
					<p className="font-bold text-lg">{item.name}</p>
				</div>
			</div>
			<p className="text-gray-500 text-sm mt-4">{item.description}</p>
		</div>
	);
}

export default memo(TestimonioCard);
