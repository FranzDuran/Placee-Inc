import Logo from "@components/Logo";
import Link from "next/link";
import React from "react";
import { BsFacebook, BsInstagram } from "react-icons/bs";

import { useTranslation } from "next-i18next";

function Footer() {
	const { t } = useTranslation("common");

	return (
		<div className="bg-white border-t mt-12 p-12">
			<div className="flex flex-col md:flex-row gap-4 items-center">
				<Link href="/">
					<div className="flex hover:scale-105 text-stone-700 duration-300 items-center gap-1 cursor-pointer text-xl font-extrabold">
						<span className="bg-primary text-white p-1 rounded-full pr-1.5">
							<Logo />
						</span>
						Aerocab
					</div>
				</Link>
				<div className="flex text-primary gap-4">
					<Link href="https://www.facebook.com/Aerocabviajes" target="_blank">
						<BsFacebook size={25} />
					</Link>

					<Link
						href="https://www.instagram.com/aerocab_oficial/"
						target="_blank"
					>
						<BsInstagram size={25} />
					</Link>
				</div>
			</div>
			<div className="flex flex-col md:justify-center gap-5 md:gap-24 md:flex-row">
				<div className=" my-4">
					<h5 className="text-primary text-lg font-bold mb-3">
						~ {t("contact")}
					</h5>

					<div className="flex text-gray-500  flex-col gap-3">
						<p>
							<strong>{t("email")}: </strong>
							reservas@aerocab.com.pe
						</p>
						<p>
							<strong>{t("phone")}: </strong>
							+51 960607020
						</p>
					</div>
				</div>
				<div>
					<h5 className="text-primary text-lg font-bold mb-3">
						~ {t("legal-texts")}
					</h5>

					<div className="flex text-gray-500  flex-col gap-3">
						<Link href="/textos-legales" className="">
							{t("terms")}
						</Link>
						<Link href="/textos-legales" className="">
							{t("privacy")}
						</Link>
					</div>
				</div>
			</div>

			<div className="flex "></div>
			<p className="text-gray-500 text-center mt-6">{t("copyrigth")}</p>
		</div>
	);
}

export default Footer;
