import Image from "next/image";
import React from "react";
import image2 from "../../../public/image2.jpg";
import FormPresupuesto from "./FormPresupuesto";
import { motion } from "framer-motion";
import { useTranslation } from "next-i18next";

function Empresas() {
	const { t } = useTranslation("companies");
	return (
		<>
			<div className="lg:text-center p-3 overflow-hidden relative mb-4">
				<div id="empresas" className="absolute top-[-95px]" />
				<motion.h4
					initial={{ opacity: 0, x: -100 }}
					whileInView={{ opacity: 1, x: 0 }}
					viewport={{ once: true }}
					transition={{ duration: 0.5 }}
					className="text-stone-700 mb-3 text-4xl lg:text-4xl font-bold"
				>
					{t("title")}
				</motion.h4>
				<motion.p
					initial={{ opacity: 0, x: -100 }}
					whileInView={{ opacity: 1, x: 0 }}
					viewport={{ once: true }}
					transition={{ duration: 0.5, delay: 0.5 }}
					className="text-gray-500 text-sm lg:text-base"
				>
					{t("paragraph1")}
				</motion.p>
			</div>
			<div className="lg:flex-row flex mx-auto flex-col p-3 justify-center gap-3 items-center">
				<div className="lg:text-center max-w-lg">
					<motion.h4
						initial={{ opacity: 0, x: -100 }}
						whileInView={{ opacity: 1, x: 0 }}
						viewport={{ once: true }}
						transition={{ duration: 0.5 }}
						className="text-blue-800 mb-3 text-3xl lg:text-4xl font-bold"
					>
						{t("subtitle2")}
					</motion.h4>
					<motion.p
						initial={{ opacity: 0, x: -100 }}
						whileInView={{ opacity: 1, x: 0 }}
						viewport={{ once: true }}
						transition={{ duration: 0.5 }}
						className="text-gray-500 mb-3 text-sm lg:text-base"
					>
						{t("paragraph2")}
					</motion.p>
				</div>
				<motion.div
					initial={{ opacity: 0, x: 100 }}
					whileInView={{ opacity: 1, x: 0 }}
					viewport={{ once: true }}
					transition={{ duration: 0.5 }}
				>
					<Image
						src={image2}
						height={500}
						width={500}
						alt="image1"
						className="rounded-lg shadow-xl skew-y-3"
					/>
				</motion.div>
			</div>
			<div className="md:flex-row-reverse flex-col p-3 w-full max-w-4xl flex mx-auto justify-center gap-3 items-center">
				<div className="lg:text-center max-w-sm">
					<h4 className="text-blue-800 mb-3 text-3xl lg:text-4xl font-bold">
						{t("subtitle3")}
					</h4>
					<p className="text-gray-500 text-sm lg:text-base">
						{t("paragraph3")}
					</p>
				</div>

				<FormPresupuesto />
			</div>
		</>
	);
}

export default Empresas;
