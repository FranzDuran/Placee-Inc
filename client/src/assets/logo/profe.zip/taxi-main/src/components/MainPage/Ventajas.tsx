import React from "react";
import { motion } from "framer-motion";
import Image from "next/image";
import image3 from "../../../public/nosotros3.png";
import { AiFillCheckCircle } from "react-icons/ai";
import { useTranslation } from "next-i18next";
import { useRouter } from "next/router";

const items = [
	{
		title: "Atención 365 dias",
		description:
			"La disponibilidad de nuestros servicios las 24 horas del día, los 7 dias de la semana.",
	},
	{
		title: "Tarifas estandarizadas",
		description: "Nuestros precios se ajustan al tipo de servicio que desees.",
	},
	{
		title: "Monitoreo GPS",
		description: "Seguimiento en tiempo real durante cada viaje.",
	},
	{
		title: "Política de cancelación flexible",
		description:
			"Cancela tu viaje hasta 1 hora antes con reembolso total sin costo total.",
	},

	{
		title: "Créditos corporativos",
		description: "Opciones de pago a corto y largo plazo para tu empresa",
	},
	{
		title: "Disponibilidad",
		description:
			"Unidades en todas las categorías para viajes dentro y fuera de Lima a toda hora.",
	},
	{
		title: "Sin fronteras",
		description: "Contamos con personal bilingüe para una mejor atención.",
	},
	{
		title: "Tiempo de espera",
		description:
			"Obtenga un período de espera de 60 minutos con cada servicio de recogida en el aeropuerto y de 15 minutos en viajes dentro de la ciudad",
	},
];

const itemsEnglish = [
	{
		title: "365 days attention",
		description: "Our services are available 24 hours a day, 7 days a week.",
	},
	{
		title: "Standardized rates",
		description: "Our prices are adjusted to the type of service you want.",
	},
	{
		title: "GPS monitoring",
		description: "Real-time tracking during each trip.",
	},
	{
		title: "Flexible cancellation policy",
		description:
			"Cancel your trip up to 1 hour before with full refund at no cost.",
	},
	{
		title: "Corporate credits",
		description: "Short and long term payment options for your company",
	},
	{
		title: "Availability",
		description:
			"Units in all categories for trips inside and outside Lima at any time.",
	},
	{
		title: "No borders",
		description: "We have bilingual staff for better attention.",
	},
	{
		title: "Waiting time",
		description:
			"Get a 60 minute waiting period with each airport pickup service and 15 minutes on city trips",
	},
];

function Ventajas() {
	const { t } = useTranslation("main");
	const router = useRouter();

	return (
		<div>
			<div className="lg:text-center mb-4">
				<motion.h4
					initial={{ opacity: 0, x: -100 }}
					whileInView={{ opacity: 1, x: 0 }}
					viewport={{ once: true }}
					transition={{ duration: 0.5 }}
					className="text-stone-700 mb-3 text-3xl lg:text-4xl font-bold"
				>
					{t("subtitle3")}
				</motion.h4>
			</div>
			<div className="flex flex-col   items-center justify-center gap-4  ">
				{/* <div className="p-3  top-0">
					<Image
						className="rounded-md  skew-x-3 shadow-lg"
						height={400}
						width={400}
						src={image3}
						alt="Nosotros"
					/>
				</div> */}
				<div className="flex text-gray-600 flex-wrap max-w-6xl justify-center gap-2">
					{router.locale === "es"
						? items.map((item, index) => (
								<motion.div
									key={index + item.title}
									initial={{ opacity: 0, x: -100 }}
									whileInView={{ opacity: 1, x: 0 }}
									viewport={{ once: true }}
									transition={{ duration: 0.5 }}
									className="p-4 max-w-lg"
								>
									<div className="flex gap-2 items-center">
										<AiFillCheckCircle className="w-8 h-8 text-primary/70" />
										<p className="text-gray-500 text-sm w-4/5">
											<strong>{item.title}:</strong> {item.description}
										</p>
									</div>
								</motion.div>
						  ))
						: itemsEnglish.map((item, index) => (
								<motion.div
									key={index + item.title}
									initial={{ opacity: 0, x: -100 }}
									whileInView={{ opacity: 1, x: 0 }}
									viewport={{ once: true }}
									transition={{ duration: 0.5 }}
									className="p-4 max-w-lg"
								>
									<div className="flex gap-2 items-center">
										<AiFillCheckCircle className="w-8 h-8 text-primary" />
										<p className="text-gray-500 text-sm w-4/5">
											<strong>{item.title}:</strong> {item.description}
										</p>
									</div>
								</motion.div>
						  ))}
				</div>
			</div>
		</div>
	);
}

export default Ventajas;
