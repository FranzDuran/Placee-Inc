import Image from "next/image";
import React from "react";
import image3 from "../../../public/nosotros1.png";
import image2 from "../../../public/nosotros2.png";

import { motion } from "framer-motion";
import { BsCheck2Circle, BsStarFill } from "react-icons/bs";
import { MdOutlineSecurity } from "react-icons/md";
import { FcIdea } from "react-icons/fc";
import { RiChatPrivateLine, RiEmotion2Line } from "react-icons/ri";
import { GiTeamIdea } from "react-icons/gi";
import { useTranslation } from "next-i18next";
import { useRouter } from "next/router";

const valores = [
	{
		title: "Excelencia",
		description:
			"Nos esforzamos por ofrecer un servicio excepcional en todo momento, superando las expectativas de nuestros clientes.",
		icon: <BsStarFill className="text-primary/80 text-4xl" />,
	},
	{
		title: "Responsabilidad",
		description:
			"Somos responsables en todo lo que hacemos, asegurándonos de cumplir con todos los requisitos legales y éticos de nuestro negocio.",
		icon: <BsCheck2Circle className="text-primary/80 text-4xl" />,
	},
	{
		title: "Privacidad",
		description:
			"Respetamos la privacidad de nuestros clientes y nos aseguramos de mantener su información confidencial en todo momento.",
		icon: <RiChatPrivateLine className="text-primary/80 text-4xl" />,
	},
	{
		title: "Seguridad",
		description:
			"La seguridad es nuestra máxima prioridad, asegurándonos de que nuestros vehículos y conductores cumplen con los más altos estándares de seguridad.",
		icon: <MdOutlineSecurity className="text-primary/80 text-4xl" />,
	},
	{
		title: "Honestidad",
		description:
			"Somos una empresa honesta y transparente en todas nuestras operaciones, manteniendo una comunicación abierta y sincera con nuestros clientes y empleados.",
		icon: <RiEmotion2Line className="text-primary/80 text-4xl" />,
	},
	{
		title: "Innovación",
		description:
			"Nos esforzamos por ser innovadores en todo lo que hacemos, buscando constantemente nuevas formas de mejorar nuestros servicios y satisfacer las necesidades de nuestros clientes.",
		icon: <FcIdea className="text-primary/80 text-4xl" />,
	},
	{
		title: "Trabajo en equipo",
		description:
			"Valoramos el trabajo en equipo y fomentamos un ambiente colaborativo y respetuoso en nuestro lugar de trabajo.",
		icon: <GiTeamIdea className="text-primary/80 text-4xl" />,
	},
];

const valoresEnglish = [
	{
		title: "Excellence",
		description:
			"We strive to provide exceptional service at all times, exceeding our customers' expectations.",
		icon: <BsStarFill className="text-primary/80 text-4xl" />,
	},
	{
		title: "Responsibility",
		description:
			"We are responsible in everything we do, making sure we comply with all the legal and ethical requirements of our business.",
		icon: <BsCheck2Circle className="text-primary/80 text-4xl" />,
	},
	{
		title: "Privacy",
		description:
			"We respect the privacy of our customers and make sure to keep your information confidential at all times.",
		icon: <RiChatPrivateLine className="text-primary/80 text-4xl" />,
	},
	{
		title: "Security",
		description:
			"Safety is our top priority, making sure our vehicles and drivers meet the highest safety standards.",
		icon: <MdOutlineSecurity className="text-primary/80 text-4xl" />,
	},
	{
		title: "Honesty",
		description:
			"We are an honest and transparent company in all our operations, maintaining open and sincere communication with our customers and employees.",
		icon: <RiEmotion2Line className="text-primary/80 text-4xl" />,
	},
	{
		title: "Innovation",
		description:
			"We strive to be innovative in everything we do, constantly looking for new ways to improve our services and meet the needs of our customers.",
		icon: <FcIdea className="text-primary/80 text-4xl" />,
	},
	{
		title: "Teamwork",
		description:
			"We value teamwork and foster a collaborative and respectful environment in our workplace.",
		icon: <GiTeamIdea className="text-primary/80 text-4xl" />,
	},
];

function Nosotros() {
	const { t } = useTranslation("about");
	const router = useRouter();
	return (
		<>
			<div className="lg:text-center p-2 overflow-hidden relative mb-4">
				<div id="nosotros" className="absolute top-[-95px]" />
				<motion.h4
					initial={{ opacity: 0, x: -100 }}
					whileInView={{ opacity: 1, x: 0 }}
					viewport={{ once: true }}
					transition={{ duration: 0.5 }}
					className="text-stone-700 mb-3 text-4xl lg:text-4xl font-bold"
				>
					{t("title-about")}
				</motion.h4>
				<motion.p
					initial={{ opacity: 0, x: -100 }}
					whileInView={{ opacity: 1, x: 0 }}
					viewport={{ once: true }}
					transition={{ duration: 0.5 }}
					className="text-gray-500 text-sm lg:text-base"
				>
					{t("paragraph-about")}
				</motion.p>
			</div>
			<div className="lg:flex-row-reverse flex mx-auto p-3 flex-col justify-center gap-3 items-center">
				<div className="lg:text-center max-w-lg">
					<motion.h4
						initial={{ opacity: 0, x: -100 }}
						whileInView={{ opacity: 1, x: 0 }}
						viewport={{ once: true }}
						transition={{ duration: 0.5 }}
						className="text-blue-800 mb-3 text-3xl lg:text-4xl font-bold"
					>
						{t("subtitle-1")}
					</motion.h4>
					<motion.p
						initial={{ opacity: 0, x: -100 }}
						whileInView={{ opacity: 1, x: 0 }}
						viewport={{ once: true }}
						transition={{ duration: 0.5 }}
						className="text-gray-500 text-sm lg:text-base"
					>
						{t("paragraph-1")}
					</motion.p>
				</div>
				<motion.div
					initial={{ opacity: 0, x: -100 }}
					whileInView={{ opacity: 1, x: 0 }}
					viewport={{ once: true }}
					transition={{ duration: 0.5 }}
				>
					<Image
						src={image3}
						height={400}
						width={400}
						loading="lazy"
						alt="image1"
						className="rounded-lg shadow-xl -skew-y-3"
					/>
				</motion.div>
			</div>
			<div className="max-w-6xl mx-auto mt-12 p-3">
				<div className="flex flex-col items-center gap-4 lg:flex-row">
					<div className="lg:w-1/2">
						<motion.h5
							initial={{ opacity: 0, x: -100 }}
							whileInView={{ opacity: 1, x: 0 }}
							viewport={{ once: true }}
							transition={{ duration: 0.5 }}
							className="text-blue-800 text-center my-3 text-3xl lg:text-4xl font-bold"
						>
							{t("subtitle-2")}
						</motion.h5>
						<motion.p
							initial={{ opacity: 0, y: -100 }}
							whileInView={{ opacity: 1, y: 0 }}
							viewport={{ once: true }}
							transition={{ duration: 0.5 }}
						>
							{t("paragraph-2")}
						</motion.p>
					</div>
					<motion.div
						initial={{ opacity: 0, x: -100 }}
						whileInView={{ opacity: 1, x: 0 }}
						viewport={{ once: true }}
						transition={{ duration: 0.5 }}
					>
						<Image
							src={image2}
							height={400}
							width={400}
							alt="image1"
							className="rounded-lg shadow-xl -skew-y-3"
						/>
					</motion.div>
				</div>

				<motion.h5
					initial={{ opacity: 0, y: -100 }}
					whileInView={{ opacity: 1, y: 0 }}
					viewport={{ once: true }}
					transition={{ duration: 0.5 }}
					className="text-blue-800 my-4 mt-8 text-3xl lg:text-4xl font-bold"
				>
					{t("subtitle-3")}
				</motion.h5>

				<motion.p
					initial={{ opacity: 0, y: -100 }}
					whileInView={{ opacity: 1, y: 0 }}
					viewport={{ once: true }}
					transition={{ duration: 0.5 }}
				>
					{t("paragraph-3")}
				</motion.p>

				<motion.h5
					initial={{ opacity: 0, y: -100 }}
					whileInView={{ opacity: 1, y: 0 }}
					viewport={{ once: true }}
					transition={{ duration: 0.5 }}
					className="text-blue-800 my-3 text-center text-3xl lg:text-4xl font-bold"
				>
					{t("subtitle-4")}
				</motion.h5>
				<div className="flex flex-wrap justify-center w-full gap-4">
					{router.locale === "es"
						? valores.map((item, index) => (
								<motion.div
									key={item.title}
									initial={{ opacity: 0, x: -100 }}
									whileInView={{ opacity: 1, x: 0 }}
									viewport={{ once: true }}
									transition={{ duration: 0.5, delay: index * 0.2 }}
									className="shadow-lg bg-white rounded-md p-3 items-center justify-center flex max-w-lg gap-6"
								>
									{item.icon}
									<div className="w-3/4">
										<h5 className="text-primary/80 font-bold text-xl">
											{item.title}
										</h5>
										<p className="text-gray-600 text-sm">{item.description}</p>
									</div>
								</motion.div>
						  ))
						: valoresEnglish.map((item, index) => (
								<motion.div
									key={item.title}
									initial={{ opacity: 0, x: -100 }}
									whileInView={{ opacity: 1, x: 0 }}
									viewport={{ once: true }}
									transition={{ duration: 0.5, delay: index * 0.2 }}
									className="shadow-lg bg-white rounded-md p-3 items-center justify-center flex max-w-lg gap-6"
								>
									{item.icon}
									<div className="w-3/4">
										<h5 className="text-primary/80 font-bold text-xl">
											{item.title}
										</h5>
										<p className="text-gray-600 text-sm">{item.description}</p>
									</div>
								</motion.div>
						  ))}
				</div>
			</div>
		</>
	);
}

export default Nosotros;
