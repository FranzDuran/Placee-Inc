import React from "react";
import { motion } from "framer-motion";
import { useTranslation } from "next-i18next";

function TextingMain() {
	const { t } = useTranslation("main");
	return (
		<div className="text-white bg-black bg-opacity-40 p-8 backdrop-blur-sm rounded-md shadow-md hidden xl:block max-w-xl">
			<motion.h1
				initial={{ opacity: 0, x: 40 }}
				animate={{ opacity: 1, x: 0 }}
				transition={{ duration: 0.5 }}
				className="text-5xl font-extrabold"
			>
				{t("title")}
			</motion.h1>
			<motion.p
				initial={{ opacity: 0, x: 40 }}
				animate={{ opacity: 1, x: 0 }}
				transition={{ duration: 0.5 }}
				className="text-lg mt-4"
			>
				{t("subtitle")}
			</motion.p>
		</div>
	);
}

export default TextingMain;
