import Footer from "@components/Navigation/Footer";
import Navbar from "@components/Navigation/Navbar";
import React from "react";
import { useTranslation } from "next-i18next";
import { serverSideTranslations } from "next-i18next/serverSideTranslations";

function TextosLegalesPage() {
	const { t } = useTranslation("legal-text");

	return (
		<>
			<div className="bg-white top-0 sticky z-50 shadow-md mb-4">
				<Navbar isSticky={true} />
			</div>

			<div className="p-3 my-14 max-w-2xl mx-auto">
				<h2 className="text-4xl dark:text-white font-bold text-slate-800 leading-10">
					{t("terms")}
					<div className="w-24 bg-gradient-to-r from-blue-500 to-primary h-1" />
				</h2>
				<p className="text-gray-500 dark:text-gray-300 py-3 text-sm">
					{t("terms-content")}
				</p>
				<h2 className="text-4xl dark:text-white font-bold text-slate-800 leading-10">
					{t("privacy")}
					<div className="w-24 bg-gradient-to-r from-blue-500 to-primary h-1" />
				</h2>
				<p className="text-gray-500 dark:text-gray-300 py-3 text-sm">
					{t("privacy-content")}
				</p>
			</div>
			<Footer />
		</>
	);
}

export default TextosLegalesPage;

export const getStaticProps = async ({ locale }: { locale: string }) => ({
	props: {
		...(await serverSideTranslations(locale!)),
	},
});
