import Empresas from "@components/MainPage/Empresas";
import Footer from "@components/Navigation/Footer";
import Navbar from "@components/Navigation/Navbar";
import { serverSideTranslations } from "next-i18next/serverSideTranslations";
import React from "react";

function EmpresasPage() {
	return (
		<>
			<div className="bg-white top-0 sticky z-50 shadow-md mb-4">
				<Navbar isSticky={true} />
			</div>

			<Empresas />
			<Footer />
		</>
	);
}

export default EmpresasPage;

export const getStaticProps = async ({ locale }: { locale: string }) => ({
	props: {
		...(await serverSideTranslations(locale!)),
	},
});
