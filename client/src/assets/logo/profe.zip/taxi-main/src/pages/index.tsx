import Image from "next/image";

import Header from "@components/MainPage/Header";
import { motion } from "framer-motion";

import portada from "../../public/portada.jpg";
import Link from "next/link";
import { BsWhatsapp } from "react-icons/bs";
import CotizarContainer from "@components/MainPage/CotizarContainer";
import TextingMain from "@components/MainPage/TextingMain";

import { useLoadScript } from "@react-google-maps/api";
import Caracteristicas from "@components/MainPage/Caracteristicas";

import Footer from "@components/Navigation/Footer";
import TestimonioList from "@components/MainPage/Testimonios";
import Ventajas from "@components/MainPage/Ventajas";
import { serverSideTranslations } from "next-i18next/serverSideTranslations";
import { useTranslation } from "next-i18next";
import Galeria from "@components/MainPage/Galeria";

export default function Home() {
	const { isLoaded } = useLoadScript({
		googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY as string,
		libraries: ["places"],
	});

	const { t } = useTranslation("common");

	if (!isLoaded)
		return (
			<div className="h-screen w-screen flex justify-center items-center bg-gray-50 animate-pulse" />
		);

	return (
		<>
			<div className="relative w-full h-full">
				<Header />
				<div className="h-[50vh] md:h-screen absolute top-0 w-full">
					<motion.div
						initial={{ opacity: 0 }}
						animate={{ opacity: 1 }}
						transition={{ duration: 0.5 }}
					>
						<Image
							src={portada}
							fill
							priority
							alt="Picture of the author"
							className="absolute z-0 object-cover w-full h-full"
						/>
					</motion.div>
					<div className="absolute inset-0 h-full w-full bg-black bg-opacity-20" />
					<div className="flex justify-center h-full z-40 items-center gap-12 relative mt-36  md:mt-4 p-3 lg:p-24">
						<CotizarContainer />
						<TextingMain />
					</div>
				</div>

				<div className="relative p-4 overflow-hidden pb-0 background mt-[65vh] md:mt-[100vh] flex flex-col gap-8">
					<Caracteristicas />
					<Ventajas />
					<Galeria />
					<TestimonioList />
				</div>
				<Footer />
				<Link
					href="https://wa.me/51960607020?text=Hola%20quiero%20mas%20informacion"
					className="fixed bottom-4 flex gap-3 items-center  right-4 z-50"
				>
					<motion.div
						initial={{ opacity: 0, x: 100 }}
						animate={{
							opacity: 1,
							x: 0,
						}}
						transition={{ duration: 0.5 }}
						className="rounded-full text-white bg-gradient-to-r font-medium from-green-500 via-green-400 to-green-500  p-3 text-sm shadow-md"
					>
						{t("chat")}
					</motion.div>
					<div className=" bg-gradient-to-r from-green-500 via-green-400 to-green-500 rounded-full p-3 text-white">
						<BsWhatsapp size={30} />
					</div>
				</Link>
			</div>
		</>
	);
}

export const getStaticProps = async ({ locale }: { locale: string }) => ({
	props: {
		...(await serverSideTranslations(locale!)),
	},
});
