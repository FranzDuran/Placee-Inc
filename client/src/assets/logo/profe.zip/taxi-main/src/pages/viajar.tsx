import LocationSelector from "@components/CotizacionPage/LocationSelector";
import Map from "@components/CotizacionPage/Map";
import Navbar from "@components/Navigation/Navbar";

import { useLoadScript } from "@react-google-maps/api";
import { serverSideTranslations } from "next-i18next/serverSideTranslations";
import { useState, useRef } from "react";

function CotizarPage() {
	const [directionsResponse, setDirectionsResponse] = useState(null);
	const refMap = useRef() as any;
	const { isLoaded } = useLoadScript({
		googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY as string,
		libraries: ["places"],
	});
	if (!isLoaded) return <div>Loading...</div>;

	return (
		<div className="h-screen flex flex-col ">
			<Navbar isSticky={true} />
			<div className="w-full flex-1 z-20 ">
				<Map ref={refMap} directionsResponse={directionsResponse} />
			</div>

			<div className="bottom-0 lg:bottom-[10%]  sm:ml-[1rem] py-[3rem] fixed  flex flex-col justify-end z-[666]">
				<LocationSelector
					setSelectedLocation={(lat: any, lng: any) =>
						refMap.current?.setSelectedLocation(lat, lng)
					}
					setSelectedLocationOrigin={(lat: any, lng: any) =>
						refMap.current?.setSelectedLocationOrigin(lat, lng)
					}
					setDirectionsResponse={setDirectionsResponse}
				/>
			</div>
		</div>
	);
}

export default CotizarPage;
export const getStaticProps = async ({ locale }: { locale: string }) => ({
	props: {
		...(await serverSideTranslations(locale!)),
	},
});
