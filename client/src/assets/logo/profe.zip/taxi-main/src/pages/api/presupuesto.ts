import nextConnect from "next-connect";
import { DocumentGoogleSheet } from "../../utils/GoogleSheet";
import { NextApiRequest, NextApiResponse } from "next";
import NodeMailer from "nodemailer";

const handler = nextConnect();

handler.post(async (req: NextApiRequest, res: NextApiResponse) => {
	const data = req.body;

	try {
		const doc = await DocumentGoogleSheet();

		const sheetCotizaciones = doc.sheetsByIndex[1];

		await sheetCotizaciones.addRow({
			NOMBRES: data.nombres,
			TELEFONO: data.telefono,
			EMAIL: data.email,
			EMPRESA: data.empresa,
			CANTIDAD_EMPLEADOS: data.cantidadEmpleados,
			RUC: data.ruc,
		});

		try {
			const transportador = NodeMailer.createTransport({
				host: "smtp.gmail.com",
				port: 465,
				secure: true,
				auth: {
					user: process.env.EMAIL,
					pass: process.env.PASS,
				},
			});
			const dataParaEnviar = {
				from: process.env.EMAIL,
				to: process.env.EMAIL,
				subject: "¡Se pidió un pedido decotización de una empresa!",
				html: `<p>Se envío un pedido de cotización! puede revisarlo aquí: <a target="_blank" href="https://docs.google.com/spreadsheets/d/${process.env.DOC_ID_GOOGLESHEET}">Clic aquí</a></p>`,
			};
			await transportador.sendMail(dataParaEnviar);
		} catch (error) {
			res.status(500).send({
				message: "Error en el servidor",
			});
		}

		return res.status(200).json({
			message: "Ready",
		});
	} catch (e) {
		return res.status(400).json({
			message: "Error",
		});
	}
});

export default handler;
