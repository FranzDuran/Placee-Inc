import "@styles/globals.css";
import type { AppProps } from "next/app";
import NProgress from "nprogress";
import Router from "next/router";
import Head from "next/head";

NProgress.configure({ showSpinner: false });
Router.events.on("routeChangeStart", () => {
	NProgress.start();
});
Router.events.on("routeChangeComplete", () => NProgress.done());
Router.events.on("routeChangeError", () => NProgress.done());
import { SnackbarProvider } from "notistack";
import { appWithTranslation } from "next-i18next";

const App = ({ Component, pageProps }: AppProps) => {
	return (
		<>
			<Head>
				<title>Aerocab - Taxis VIP</title>
				<meta
					name="description"
					content="
					 Transporte VIP de pasajeros, con la mejor atención y seguridad.
					"
				/>
				<meta name="keywords" content="Taxis, Aeropuerto, VIP, Aerocab" />
				<meta name="viewport" content="width=device-width, initial-scale=1" />
				<link rel="icon" href="/icon.jpg" />
			</Head>
			<SnackbarProvider>
				<Component {...pageProps} />
			</SnackbarProvider>
		</>
	);
};

export default appWithTranslation(App);
