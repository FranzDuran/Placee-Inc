import Nosotros from "@components/MainPage/Nosotros";
import Footer from "@components/Navigation/Footer";
import Navbar from "@components/Navigation/Navbar";
import { serverSideTranslations } from "next-i18next/serverSideTranslations";
import React from "react";

function NosotrosPages() {
	return (
		<>
			<div className="bg-white top-0 sticky z-50 shadow-md mb-4">
				<Navbar isSticky={true} />
			</div>
			<Nosotros />
			<Footer />
		</>
	);
}

export default NosotrosPages;

export const getStaticProps = async ({ locale }: { locale: string }) => ({
	props: {
		...(await serverSideTranslations(locale!)),
	},
});
